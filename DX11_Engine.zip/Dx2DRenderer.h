#pragma once
#include "IDraw.h"

struct VERTEX
{
	FLOAT X, Y, Z;
};


class Quad
{
public:
	Quad();
	~Quad();
	void update();
	void Draw();
	HRESULT createInputLayout(ID3DBlob* mBlob);

public:

	
	VERTEX Vt[4];

	int mVertexCount = 0;
	ID3D11Buffer* mVertexBuffer = nullptr;
	ID3D11InputLayout* mVertexLayout = nullptr;

};


class VsShader
{
public:

	VsShader(const WCHAR* fileName);
	~VsShader();

	void Draw();

	ID3DBlob* mBlob = nullptr;
	ID3D11VertexShader* mVertexShader;

};

class PsShader
{
public:
	PsShader(const WCHAR* fileName);
	~PsShader();

	void Draw();

	ID3D11PixelShader* mPixelShader;
};




class Dx2DRenderer : public IDraw
{
public:
	Dx2DRenderer();
	~Dx2DRenderer();

	void Draw() override;
	void Update() override;

public:
	Quad* mQuad = nullptr;
	VsShader* mVsShader = nullptr;
	PsShader* mPsShader = nullptr;

};

