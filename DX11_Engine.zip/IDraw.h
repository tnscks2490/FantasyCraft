#pragma once


class IDraw
{
public:
	virtual void Update() = 0;
	virtual void Draw() = 0;
};
