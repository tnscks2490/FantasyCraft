#include "pch.h"
#include "Components.h"
#include "Dx2DRenderer.h"

Quad::Quad()
{
	Vt[0] = { -0.5f,-0.5f,0.0f };
	Vt[1] = { -0.5f, 0.5f,0.0f };
	Vt[2] = { 0.5f,-0.5f,0.0f };
	Vt[3] = { 0.5f,0.5f,0.0f };

	mVertexCount = 4;

	D3D11_BUFFER_DESC bd;
	ZeroMemory(&bd, sizeof(bd));

	bd.Usage = D3D11_USAGE_DYNAMIC;
	bd.ByteWidth = sizeof(VERTEX) * mVertexCount;
	bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

	HRESULT hr = g_Dx11.device->CreateBuffer(&bd, NULL, &mVertexBuffer);
	
}

Quad::~Quad()
{
	SAFE_RELEASE(mVertexBuffer);
	SAFE_RELEASE(mVertexLayout);
}

void Quad::update()
{
	D3D11_MAPPED_SUBRESOURCE ms;
	g_Dx11.context->Map(mVertexBuffer, NULL, D3D11_MAP_WRITE_DISCARD, NULL, &ms);
	memcpy(ms.pData, Vt, sizeof(Vt));
	g_Dx11.context->Unmap(mVertexBuffer, NULL);
}

void Quad::Draw()
{
	update();

	g_Dx11.context->IASetInputLayout(mVertexLayout);

	UINT stride = sizeof(VERTEX);
	UINT offset = 0;
	g_Dx11.context->IASetVertexBuffers(0, 1, &mVertexBuffer, &stride, &offset);
	g_Dx11.context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
}

HRESULT Quad::createInputLayout(ID3DBlob* mBlob)
{
	HRESULT hr;

	D3D11_INPUT_ELEMENT_DESC layout[] = {
		{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0}
	};
	UINT numElements = ARRAYSIZE(layout);

	hr = g_Dx11.device->CreateInputLayout(layout,
											numElements,
											mBlob->GetBufferPointer(),
											mBlob->GetBufferSize(),
											&mVertexLayout);

	return hr;
}

VsShader::VsShader(const WCHAR* fileName)
{
	HRESULT result;
	result = D3DReadFileToBlob(fileName, &mBlob);
	result = g_Dx11.device->CreateVertexShader(mBlob->GetBufferPointer(),
		mBlob->GetBufferSize(),
		0, 
		&mVertexShader);
}

VsShader::~VsShader()
{
	SAFE_RELEASE(mVertexShader)
	SAFE_RELEASE(mBlob)
	
}

void VsShader::Draw()
{
	g_Dx11.context->VSSetShader(mVertexShader, 0, 0);
}

PsShader::PsShader(const WCHAR* fileName)
{
	HRESULT result;
	ID3DBlob* mBlob = nullptr;

	result = D3DReadFileToBlob(fileName, &mBlob);
	result = g_Dx11.device->CreatePixelShader(mBlob->GetBufferPointer(), 
		mBlob->GetBufferSize(), 
		0, 
		&mPixelShader);

	mBlob->Release();
}

PsShader::~PsShader()
{
	SAFE_RELEASE(mPixelShader)
}

void PsShader::Draw()
{
	g_Dx11.context->PSSetShader(mPixelShader, 0, 0);
}

Dx2DRenderer::Dx2DRenderer()
{
	mVsShader = new VsShader(L"VS.cso");
	mPsShader = new PsShader(L"PS.cso");
	mQuad = new Quad;

	if (!mQuad->mVertexLayout) 
		mQuad->createInputLayout(mVsShader->mBlob);
}

Dx2DRenderer::~Dx2DRenderer()
{
	SAFE_DELETE(mQuad);
	SAFE_DELETE(mVsShader);
	SAFE_DELETE(mPsShader);
}

void Dx2DRenderer::Draw()
{
	mQuad->Draw();
	mVsShader->Draw();
	mPsShader->Draw();
	g_Dx11.context->Draw(mQuad->mVertexCount, 0);
}

void Dx2DRenderer::Update()
{
}
